import React, { useContext } from 'react';
import { ResumeContext } from '../context/ResumeContext';

const PersonalDetails = () => {
  const { personalDetails, setPersonalDetails } = useContext(ResumeContext);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPersonalDetails({ ...personalDetails, [name]: value });
  };

  return (
    <div>
      <h2>Personal Details</h2>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="email" placeholder="Email" onChange={handleChange} />
      <input name="phone" placeholder="Phone" onChange={handleChange} />
    </div>
  );
};

export default PersonalDetails;
