import React, { useContext, useState } from 'react';
import { ResumeContext } from '../context/ResumeContext';

const Education = () => {
  const { education, setEducation } = useContext(ResumeContext);
  const [newEducation, setNewEducation] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewEducation({ ...newEducation, [name]: value });
  };

  const handleAdd = () => {
    setEducation([...education, newEducation]);
    setNewEducation({});
  };

  return (
    <div>
      <h2>Education</h2>
      <input name="degree" placeholder="Degree" onChange={handleChange} />
      <input name="school" placeholder="School" onChange={handleChange} />
      <input name="city" placeholder="City" onChange={handleChange} />
      <input name="startDate" placeholder="Start Date" onChange={handleChange} />
      <input name="endDate" placeholder="End Date" onChange={handleChange} />
      <button onClick={handleAdd}>Add Education</button>
      <ul>
        {education.map((edu, index) => (
          <li key={index}>{edu.degree} at {edu.school}, {edu.city} ({edu.startDate} - {edu.endDate})</li>
        ))}
      </ul>
    </div>
  );
};

export default Education;
