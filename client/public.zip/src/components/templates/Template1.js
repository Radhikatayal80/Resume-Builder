import React, { useContext } from 'react';
import { ResumeContext } from '../../context/ResumeContext';

const Template1 = () => {
  const { personalDetails, education } = useContext(ResumeContext);

  return (
    <div className="template1">
     
      <h2>Education</h2>
      <ul>
      <h1>{personalDetails.name}</h1>
      <p>{personalDetails.email}</p>
      <p>{personalDetails.phone}</p>
        {education.map((edu, index) => (
          <li key={index}>{edu.degree} at {edu.school}, {edu.city} ({edu.startDate} - {edu.endDate})</li>
        ))}
      </ul>
    </div>
  );
};

export default Template1;
